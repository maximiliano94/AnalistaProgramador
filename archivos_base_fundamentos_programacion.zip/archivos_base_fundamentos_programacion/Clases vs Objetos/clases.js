class vivienda {

    constructor(paredes, ventanas) {
    
    this.paredes = paredes;
    
    this.ventanas = ventanas;
    
    }
    
    }
    
    let casa = new casa(4, 2);
    
    console.log(casa.paredes);