class Car {
    constructor(name, year) {
      this.name = name;
      this.year = year;
    }
  }
  
  myCar = new Car("Maricarmen", 2014);