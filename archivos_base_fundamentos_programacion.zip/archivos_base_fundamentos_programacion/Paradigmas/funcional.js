int z;
function notPure(){
	z = z+10;
}