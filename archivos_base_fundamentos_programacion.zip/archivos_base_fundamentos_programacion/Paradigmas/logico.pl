man(socrates).
mortal(X) :- man(X).

?- mortal(socrates).